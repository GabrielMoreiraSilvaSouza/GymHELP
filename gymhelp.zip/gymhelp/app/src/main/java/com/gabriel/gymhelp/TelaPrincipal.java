package com.gabriel.gymhelp;

import android.content.Intent;
import androidx.annotation.Nullable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class TelaPrincipal extends AppCompatActivity {

    private TextView nomeUsuario, emailUsuario;
    private Button bt_deslogar, bt_consultarEquipamentos;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    String usuarioID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Habilitar Edge-to-Edge UI
        EdgeToEdge.enable(this);

        // Configurar o layout da atividade
        setContentView(R.layout.activity_tela_principal);

        // Ocultar a barra de ação
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Inicializar componentes
        IniciarComponentes();

        // Configurar o clique do botão de logout
        bt_deslogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(TelaPrincipal.this, FormLogin.class);
                startActivity(intent);
                finish();
            }
        });

        // Configurar o clique do novo botão para navegar para uma nova tela
        bt_consultarEquipamentos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navega para a NovaTelaActivity
                Intent intent = new Intent(TelaPrincipal.this, NovaTelaActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        String email = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null) {
                    nomeUsuario.setText(documentSnapshot.getString("nome"));
                    emailUsuario.setText(email);
                }
            }
        });
    }

    // Ajustar padding para lidar com as margens do sistema
    private void AjustarPadding() {
        View mainView = findViewById(R.id.main);
        if (mainView != null) { // Verificação para evitar NullPointerException
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
    }

    // Inicializar os componentes da tela
    private void IniciarComponentes(){
        nomeUsuario = findViewById(R.id.textNomeUsuario);
        emailUsuario = findViewById(R.id.textEmailUsuario);
        bt_deslogar = findViewById(R.id.bt_deslogar);
        bt_consultarEquipamentos = findViewById(R.id.bt_consultarEquipamentos);  // Referência ao novo botão

        // Carregar dados do usuário logado
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            nomeUsuario.setText(FirebaseAuth.getInstance().getCurrentUser().getDisplayName());
            emailUsuario.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
        }
    }
}
